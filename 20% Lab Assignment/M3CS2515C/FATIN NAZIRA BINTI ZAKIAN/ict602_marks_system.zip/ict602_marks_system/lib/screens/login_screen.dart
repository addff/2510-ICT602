import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'admin_home.dart';
import 'lecturer_home.dart';
import 'student_home.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        bool isMobile = constraints.maxWidth < 600;
        bool isTablet = constraints.maxWidth >= 600 && constraints.maxWidth < 1024;
        
        return Scaffold(
          appBar: AppBar(
            title: Text(
              'ICT602 Marks System',
              style: TextStyle(fontSize: isMobile ? 20 : 24),
            ),
            centerTitle: true,
          ),
          body: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(isMobile ? 20 : isTablet ? 30 : 40),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: isMobile ? 400 : isTablet ? 500 : 600,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Logo/Header
                    Column(
                      children: [
                        Icon(
                          Icons.school,
                          size: isMobile ? 60 : 80,
                          color: Colors.blue,
                        ),
                        SizedBox(height: isMobile ? 10 : 16),
                        Text(
                          'Welcome Back',
                          style: TextStyle(
                            fontSize: isMobile ? 24 : 30,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[800],
                          ),
                        ),
                        SizedBox(height: isMobile ? 5 : 8),
                        Text(
                          'Multi-Level Login System',
                          style: TextStyle(
                            fontSize: isMobile ? 14 : 16,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                    
                    SizedBox(height: isMobile ? 30 : 40),
                    
                    // Login Card
                    Card(
                      elevation: 4,
                      child: Padding(
                        padding: EdgeInsets.all(isMobile ? 20 : 28),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Login to Continue',
                              style: TextStyle(
                                fontSize: isMobile ? 18 : 22,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey[800],
                              ),
                            ),
                            
                            SizedBox(height: isMobile ? 20 : 28),
                            
                            // Email Field
                            Text(
                              'Email Address',
                              style: TextStyle(
                                fontSize: isMobile ? 14 : 16,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey[700],
                              ),
                            ),
                            SizedBox(height: 8),
                            TextField(
                              controller: _emailController,
                              keyboardType: TextInputType.emailAddress,
                              decoration: InputDecoration(
                                hintText: 'Enter your email',
                                prefixIcon: Icon(Icons.email),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: isMobile ? 16 : 20,
                                  vertical: isMobile ? 14 : 18,
                                ),
                              ),
                            ),
                            
                            SizedBox(height: isMobile ? 16 : 22),
                            
                            // Password Field
                            Text(
                              'Password',
                              style: TextStyle(
                                fontSize: isMobile ? 14 : 16,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey[700],
                              ),
                            ),
                            SizedBox(height: 8),
                            TextField(
                              controller: _passwordController,
                              obscureText: true,
                              decoration: InputDecoration(
                                hintText: 'Enter your password',
                                prefixIcon: Icon(Icons.lock),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: isMobile ? 16 : 20,
                                  vertical: isMobile ? 14 : 18,
                                ),
                              ),
                            ),
                            
                            SizedBox(height: isMobile ? 24 : 32),
                            
                            // Login Button
                            SizedBox(
                              width: double.infinity,
                              height: isMobile ? 50 : 56,
                              child: ElevatedButton(
                                onPressed: () async {
                                  final currentContext = context;
                                  String email = _emailController.text.trim();
                                  String password = _passwordController.text.trim();
                                  
                                  bool success = await authProvider.login(email, password);
                                  
                                  if (!mounted) return;
                                  
                                  if (success) {
                                    Navigator.pushReplacement(
                                      currentContext,
                                      MaterialPageRoute(builder: (context) {
                                        switch (authProvider.user!.role) {
                                          case 'admin':
                                            return AdminHome();
                                          case 'lecturer':
                                            return LecturerHome();
                                          case 'student':
                                            return StudentHome();
                                          default:
                                            return StudentHome();
                                        }
                                      }),
                                    );
                                  } else {
                                    ScaffoldMessenger.of(currentContext).showSnackBar(
                                      SnackBar(
                                        content: Text('Login failed. Please check your credentials.'),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                },
                                child: Text(
                                  'Login',
                                  style: TextStyle(
                                    fontSize: isMobile ? 16 : 18,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
              SizedBox(height: isMobile ? 25 : 32),
                    
                 
                  
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  
    

}