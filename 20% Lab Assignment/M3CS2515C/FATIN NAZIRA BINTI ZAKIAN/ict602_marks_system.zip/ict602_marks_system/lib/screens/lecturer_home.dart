import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import './login_screen.dart';

class LecturerHome extends StatefulWidget {
  const LecturerHome({super.key});

  @override
  State<LecturerHome> createState() => _LecturerHomeState();
}

class _LecturerHomeState extends State<LecturerHome> {
  List<Map<String, dynamic>> students = [];
  Map<String, dynamic>? selectedStudent;

  final Map<String, TextEditingController> _controllers = {
    'test': TextEditingController(),
    'assignment': TextEditingController(),
    'project': TextEditingController(),
  };

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  Future<void> _loadStudents() async {
    try {
      setState(() => isLoading = true);

      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('role', isEqualTo: 'student')
          .get();

      students = snapshot.docs.map((doc) {
        return {
          'id': doc.id,
          'name': doc['name'] ?? 'No Name',
          'matric': doc['matricNumber'] ?? 'No Matric',
        };
      }).toList();

      selectedStudent = students.isNotEmpty ? students.first : null;

      setState(() => isLoading = false);
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  

  Future<void> _showLogoutDialog() async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: const [
              Icon(Icons.logout, color: Colors.red),
              SizedBox(width: 8),
              Text('Logout'),
            ],
          ),
          content: const Text(
            'Are you sure you want to logout?',
            style: TextStyle(fontSize: 16),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              onPressed: () {
                Navigator.pop(context);
                _logout();
              },
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

  void _logout() {
    Provider.of<AuthProvider>(context, listen: false).logout();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => LoginScreen()),
      (_) => false,
    );
  }

  

  Future<void> _saveMarks() async {
    if (selectedStudent == null) return;

    final test = double.tryParse(_controllers['test']!.text) ?? 0;
    final assignment =
        double.tryParse(_controllers['assignment']!.text) ?? 0;
    final project = double.tryParse(_controllers['project']!.text) ?? 0;

    if (test < 0 ||
        test > 100 ||
        assignment < 0 ||
        assignment > 100 ||
        project < 0 ||
        project > 100) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Marks must be between 0 and 100')),
      );
      return;
    }

    final total = (test * 0.20) + (assignment * 0.10) + (project * 0.20);
    final auth = Provider.of<AuthProvider>(context, listen: false);

    await FirebaseFirestore.instance
        .collection('users')
        .doc(selectedStudent!['id'])
        .update({
      'marks': {
        'test': test,
        'assignment': assignment,
        'project': project,
        'total': total,
        'updated_by': auth.user!.id,
        'updated_at': FieldValue.serverTimestamp(),
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('✅ Marks saved for ${selectedStudent!['name']}'),
        backgroundColor: Colors.green,
      ),
    );

    _controllers.values.forEach((c) => c.clear());
    setState(() {});
  }

  @override
  void dispose() {
    _controllers.values.forEach((c) => c.dispose());
    super.dispose();
  }

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: const Text('Enter Carry Marks - ICT602'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: _showLogoutDialog, 
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 48),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 900),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _welcomeCard(),
                      const SizedBox(height: 24),
                      _studentSelector(),
                      const SizedBox(height: 24),
                      _marksInputCard(),
                      const SizedBox(height: 24),
                      _infoCard(),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  Widget _welcomeCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: const [
            Icon(Icons.school, color: Colors.blue),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Welcome, Lecturer',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _studentSelector() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Student',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<Map<String, dynamic>>(
              initialValue: selectedStudent,
              isExpanded: true,
              decoration: const InputDecoration(border: OutlineInputBorder()),
              items: students.map((s) {
                return DropdownMenuItem(
                  value: s,
                  child: Text('${s['name']} (${s['matric']})'),
                );
              }).toList(),
              onChanged: (value) => setState(() => selectedStudent = value),
            ),
          ],
        ),
      ),
    );
  }

  Widget _marksInputCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enter Marks (0–100)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            _markField('Test (20%)', 'test'),
            const SizedBox(height: 12),
            _markField('Assignment (10%)', 'assignment'),
            const SizedBox(height: 12),
            _markField('Project (20%)', 'project'),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: _saveMarks,
                icon: const Icon(Icons.save),
                label: const Text('SAVE MARKS'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _markField(String label, String key) {
    return TextField(
      controller: _controllers[key],
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
    );
  }

  Widget _infoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info, color: Colors.blue),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Marks Distribution',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text('• Test: 20%'),
          Text('• Assignment: 10%'),
          Text('• Project: 20%'),
          Text('• Carry Mark Total: 50%'),
        ],
      ),
    );
  }
}
