import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/mark_calculator.dart';
import './login_screen.dart';

class StudentHome extends StatefulWidget {
  const StudentHome({super.key});

  @override
  State<StudentHome> createState() => _StudentHomeState();
}

class _StudentHomeState extends State<StudentHome> {
  Map<String, double> marks = {
    'test': 0.0,
    'assignment': 0.0,
    'project': 0.0,
    'total': 0.0,
  };

  String studentName = 'Loading...';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    await _loadStudentData();
    await _loadMarks();
  }

  Future<void> _loadStudentData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(authProvider.user!.id)
        .get();

    if (doc.exists) {
      setState(() {
        studentName = doc['name'] ?? 'Student';
      });
    }
  }

  Future<void> _loadMarks() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(authProvider.user!.id)
        .get();

    if (doc.exists && doc.data()!.containsKey('marks')) {
      final m = doc['marks'];
      setState(() {
        marks['test'] = _parse(m['test']);
        marks['assignment'] = _parse(m['assignment']);
        marks['project'] = _parse(m['project']);
        marks['total'] =
            (marks['test']! * 0.20) +
            (marks['assignment']! * 0.10) +
            (marks['project']! * 0.20);
      });
    }
  }

  double _parse(dynamic v) {
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0;
    return 0;
  }

  void _logout() {
    Provider.of<AuthProvider>(context, listen: false).logout();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: Text('$studentName - Carry Mark'),
        actions: [
          IconButton(icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          bool isMobile = constraints.maxWidth < 600;

          return SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 40), 
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 900),
                child: Column(
                  mainAxisSize: MainAxisSize.min, 
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '📊 Current Marks - ICT602',
                              style: TextStyle(
                                fontSize: isMobile ? 20 : 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 20),

                            GridView.count(
                              crossAxisCount: isMobile ? 1 : 3,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              childAspectRatio: isMobile ? 3.6 : 2, 
                              mainAxisSpacing: 12,
                              children: [
                                _markCard('Assignment', '10%', marks['assignment']!),
                                _markCard('Project', '20%', marks['project']!),
                                _markCard('Test', '20%', marks['test']!),
                              ],
                            ),

                            const SizedBox(height: 20),

                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade50,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                children: [
                                  const Text(
                                    'Carry Mark Total',
                                    style: TextStyle(fontSize: 18),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    '${marks['total']!.toStringAsFixed(1)}%',
                                    style: const TextStyle(
                                      fontSize: 36,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const Text('out of 50%'),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            ElevatedButton.icon(
                              onPressed: _loadMarks,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Refresh Marks'),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 30),

                    MarkCalculator(currentTotal: marks['total']!),

                    const SizedBox(height: 30),

                    _infoBox(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _markCard(String title, String weight, double mark) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(weight),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${mark.toStringAsFixed(1)}%',
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.info, color: Colors.blue),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'How Marks Are Calculated',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text('• Carry Mark = 50%'),
          const Text('• Final Exam = 50%'),
        ],
      ),
    );
  }
}
