import 'package:flutter/material.dart';

class MarkCalculator extends StatefulWidget {
  final double currentTotal; // Carry mark (0–50)

  const MarkCalculator({
    Key? key,
    required this.currentTotal,
  }) : super(key: key);

  @override
  State<MarkCalculator> createState()=> _MarkCalculatorState  ();
}

class _MarkCalculatorState extends State<MarkCalculator> {
  final Map<String, Map<String, dynamic>> gradeData = {
    'A+': {'min': 90, 'max': 100, 'value': 4.0},
    'A': {'min': 80, 'max': 89, 'value': 4.0},
    'A-': {'min': 75, 'max': 79, 'value': 3.67},
    'B+': {'min': 70, 'max': 74, 'value': 3.33},
    'B': {'min': 65, 'max': 69, 'value': 3.0},
    'B-': {'min': 60, 'max': 64, 'value': 2.67},
    'C+': {'min': 55, 'max': 59, 'value': 2.33},
    'C': {'min': 50, 'max': 54, 'value': 2.0},
  };

  String? selectedGrade;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final isMobile = c.maxWidth < 600;

        return Card(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Padding(
            // ✅ EXTRA BOTTOM padding (anti web overflow)
            padding: EdgeInsets.fromLTRB(
              isMobile ? 16 : 20,
              isMobile ? 16 : 20,
              isMobile ? 16 : 20,
              isMobile ? 28 : 32,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min, 
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _header(isMobile),
                const SizedBox(height: 20),
                _carryMarkCard(isMobile),
                const SizedBox(height: 24),
                _gradeSelector(isMobile),
                const SizedBox(height: 24),
                if (selectedGrade != null) ...[
                  _resultSection(isMobile),
                  const SizedBox(height: 24),
                  _allGradesTable(isMobile),
                ],
              ],
            ),
          ),
        );
      },
    );
  }


  Widget _header(bool isMobile) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.blue.shade50  ,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.calculate, color:  Colors.blue),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Text(
            'Final Exam Target Calculator',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  Widget _carryMarkCard(bool isMobile) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade50, Colors.blue.shade100],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Current Carry Mark',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text(
            '${widget.currentTotal.toStringAsFixed(1)}%',
            style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
          ),
          const Text('out of 50%'),
        ],
      ),
    );
  }

 
  Widget _gradeSelector(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Select Target Grade:',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: DropdownButton<String>(
            value: selectedGrade,
            hint: const Text('Choose a grade'),
            isExpanded: true,
            underline: const SizedBox(),
            items: gradeData.entries.map((e) {
              return DropdownMenuItem<String>(
                value: e.key,
                child: Row(
                  children: [
                    _gradeBadge(e.key),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min, 
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Grade ${e.key} (${e.value['min']}-${e.value['max']}%)'),
                          const SizedBox(height: 2),
                          Text(
                            'GPA ${e.value['value']}',
                            style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
            onChanged: (v) => setState(() => selectedGrade = v),
          ),
        ),
      ],
    );
  }


  Widget _resultSection(bool isMobile) {
    final data = gradeData[selectedGrade]!;
    final requiredFinal = _requiredFinal(data['min']);
    final contribution = requiredFinal * 0.5;
    final total = widget.currentTotal + contribution;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _gradeColor(selectedGrade!).withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _gradeColor(selectedGrade!)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Target Grade $selectedGrade',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: _gradeColor(selectedGrade!),
            ),
          ),
          const SizedBox(height: 12),
          _row('Final Exam Needed', '${requiredFinal.toStringAsFixed(1)}%'),
          _row('Final Contribution', '${contribution.toStringAsFixed(1)}%'),
          const Divider(height: 20),
          _row(
            'Total Marks',
            '${total.toStringAsFixed(1)}%',
            isBold: true,
          ),
        ],
      ),
    );
  }

  
  Widget _allGradesTable(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'All Grade Targets',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        ...gradeData.entries.map((e) {
          final req = _requiredFinal(e.value['min']);
          final possible = req <= 100;
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              children: [
                _gradeBadge(e.key),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min, 
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Grade ${e.key} (${e.value['min']}-${e.value['max']}%)'),
                      const SizedBox(height: 2),
                      Text(
                        'Final exam: ${req.toStringAsFixed(1)}%',
                        style: TextStyle(
                          fontSize: 13,
                          color: possible ? Colors.green : Colors.red,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  possible ? Icons.check_circle : Icons.cancel,
                  color: possible ? Colors.green : Colors.red,
                ),
              ],
            ),
          );
        }).toList(),
      ],
    );
  }

 
  Widget _row(String label, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(
          value,
          style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.w600),
        ),
      ],
    );
  }

  Widget _gradeBadge(String grade) {
    return Container(
      width: 44,
      height: 32,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: _gradeColor(grade).withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _gradeColor(grade)),
      ),
      child: Text(
        grade,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: _gradeColor(grade),
        ),
      ),
    );
  }

  double _requiredFinal(int target) {
    final r = (target - widget.currentTotal) / 0.5;
    if (r < 0) return 0;
    if (r > 100) return 100;
    return double.parse(r.toStringAsFixed(1));
  }

  Color _gradeColor(String g) {
    if (g.startsWith('A')) return Colors.green.shade700;
    if (g.startsWith('B')) return Colors.blue.shade600;
    return Colors.orange.shade600;
  }
}
