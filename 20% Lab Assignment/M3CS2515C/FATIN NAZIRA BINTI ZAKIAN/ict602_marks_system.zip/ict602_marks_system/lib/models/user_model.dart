class UserModel {
  String id;
  String email;
  String role;
  String name;

  UserModel({
    required this.id,
    required this.email,
    required this.role,
    required this.name,
  });
}