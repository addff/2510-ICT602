import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ict602_marks_system/models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

 // lib/services/auth_service.dart
Future<UserModel?> login(String email, String password) async {
  try {
    // 1. Login dengan Firebase Auth
    UserCredential userCredential = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    
    // 2. Dapat user ID dari Auth
    String userId = userCredential.user!.uid;
    
    // 3. Ambil data dari Firestore
    DocumentSnapshot userDoc = await _firestore
        .collection('users')
        .doc(userId)  // ❗GUNA USER ID, BUKAN EMAIL
        .get();
    
    if (userDoc.exists) {
      return UserModel(
        id: userDoc.id,
        email: userDoc['email'],
        role: userDoc['role'],
        name: userDoc['name'],
      );
    }
    return null;
  } catch (e) {
    print("Login error: $e");
    return null;
  }
}
}