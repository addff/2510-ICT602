package com.example.ict602_marks_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
